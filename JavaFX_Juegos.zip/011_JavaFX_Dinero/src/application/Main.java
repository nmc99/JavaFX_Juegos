package application;

import java.util.ArrayList;
import java.util.Iterator;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import application.*;

public class Main extends Application {
	
	long lastNanoTime = System.nanoTime();

	int score = 0;
	@Override
	public void start(Stage theStage) {
		theStage.setTitle("EQUISDEDE");

		Group root = new Group();
		Scene theScene = new Scene(root);
		theStage.setScene(theScene);

		Canvas canvas = new Canvas(512, 512);
		root.getChildren().add(canvas);

		ArrayList<String> input = new ArrayList<String>();

		theScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				if (!input.contains(code))
					input.add(code);
			}
		});

		theScene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				input.remove(code);
			}
		});

		GraphicsContext gc = canvas.getGraphicsContext2D();

		Font theFont = Font.font("Helvetica", FontWeight.BOLD, 24);
		gc.setFont(theFont);
		gc.setFill(Color.GREEN);
		gc.setStroke(Color.BLACK);
		gc.setLineWidth(1);

		Sprite briefcase = new Sprite();
		briefcase.setImage("coche.png");
		briefcase.setPosition(200, 0);

		ArrayList<Sprite> dineroList = new ArrayList<Sprite>();
		ArrayList<Sprite> falloList = new ArrayList<Sprite>();

		for (int i = 0; i < 10; i++) {
			Sprite dinero = new Sprite();
			dinero.setImage("money.png");
			double px = 350 * Math.random() + 50;
			double py = 350 * Math.random() + 50;
			dinero.setPosition(px, py);
			dineroList.add(dinero);
		}
		
		for (int i = 0; i < 15; i++) {
			Sprite fallo = new Sprite();
			if(i%2 == 0) {
				fallo.setImage("arbol.png");
			} else {
				fallo.setImage("persona.png");
			}
			
			double px = 350 * Math.random() + 50;
			double py = 350 * Math.random() + 50;
			fallo.setPosition(px, py);
			falloList.add(fallo);
		}

		

		new AnimationTimer() {
			public void handle(long currentNanoTime) {
				// calculate time since last update.
				double elapsedTime = (currentNanoTime - lastNanoTime) / 1000000000.0;
				lastNanoTime = currentNanoTime;

				// game logic

				briefcase.setVelocity(0, 0);
				if (input.contains("LEFT"))
					briefcase.addVelocity(-500, 0);
				if (input.contains("RIGHT"))
					briefcase.addVelocity(500, 0);
				if (input.contains("UP"))
					briefcase.addVelocity(0, -500);
				if (input.contains("DOWN"))
					briefcase.addVelocity(0, 500);

				briefcase.update(elapsedTime);

				// collision detection

				Iterator<Sprite> moneybagIter = dineroList.iterator();
				Iterator<Sprite> falloIter = falloList.iterator();

				while (moneybagIter.hasNext()) {
					Sprite moneybag = moneybagIter.next();
					if (briefcase.intersects(moneybag)) {
						moneybagIter.remove();
						score++;
					}
				}
				
				while (falloIter.hasNext()) {
					Sprite fallo = falloIter.next();
					if (briefcase.intersects(fallo)) {
						falloIter.remove();
						score--;
					}
				}

				// render

				gc.clearRect(0, 0, 512, 512);
				briefcase.render(gc);

				for (Sprite hoja : dineroList)
					hoja.render(gc);
				
				for (Sprite fallo : falloList)
					fallo.render(gc);

				String pointsText = "Cash: $" + (10 * score);
				gc.fillText(pointsText, 360, 36);
				gc.strokeText(pointsText, 360, 36);
			}
		}.start();

		theStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
