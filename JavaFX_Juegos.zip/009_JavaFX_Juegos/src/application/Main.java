package application;
	
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			
			Group root = new Group();
			primaryStage.setTitle("SISTEMA SOLAR");
			Scene scene = new Scene(root,600,600);
			
			Canvas canvas = new Canvas(600, 600);
			root.getChildren().add(canvas);
			
			GraphicsContext gc = canvas.getGraphicsContext2D();
			
			Image img = new Image("tierra.png");
			Image img2 = new Image("sun.jpg");
			Image img3 = new Image("universo.jpg");
			// Image img2 = new Image(getClass().getResource("tierra.png").toExternalForm());
			gc.drawImage(img3, 0, 0);
			gc.drawImage(img, 0, 0);
			gc.drawImage(img2, 175, 145);
			
			final long startNanoTime = System.nanoTime();
			 
		    new AnimationTimer()
		    {
		        public void handle(long currentNanoTime)
		        {
		            double t = (currentNanoTime - startNanoTime) / 1000000000.0; 
		 
		            double x = 232 + 128 * Math.cos(t);
		            double y = 232 + 128 * Math.sin(t);
		 
		            // background image clears canvas
		            gc.drawImage( img3, 0, 0 );
		            gc.drawImage( img, x, y );
		            gc.drawImage( img2, 196, 196 );
		        }
		    }.start();
			
			
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
